# Creative Tic-Tac-Toe Game

# Initialize the board
board = [" " for _ in range(9)]

# Function to display the Tic-Tac-Toe board with a creative design
def display_board():
    print("   |   |   ")
    print(f" {board[0]} | {board[1]} | {board[2]} ")
    print("___|___|___")
    print("   |   |   ")
    print(f" {board[3]} | {board[4]} | {board[5]} ")
    print("___|___|___")
    print("   |   |   ")
    print(f" {board[6]} | {board[7]} | {board[8]} ")
    print("   |   |   ")

# Function to check if a player has won
def check_winner(player):
    # Check rows
    for i in range(0, 9, 3):
        if all(board[i:i+3] == [player, player, player]):
            return True

    # Check columns
    for i in range(3):
        if all(board[i::3] == [player, player, player]):
            return True

    # Check diagonals
    if all(board[0::4] == [player, player, player]) or all(board[2:7:2] == [player, player, player]):
        return True

    return False

# Function to check if the board is full (game ends in a draw)
def is_board_full():
    return " " not in board

# Main game loop
current_player = "X"
print("Welcome to Creative Tic-Tac-Toe!")
while True:
    display_board()
    print(f"Player {current_player}'s turn. Enter a position (1-9): ", end="")
    position = int(input()) - 1

    if position < 0 or position > 8 or board[position] != " ":
        print("Invalid move. Try again.")
        continue

    board[position] = current_player

    if check_winner(current_player):
        display_board()
        print(f"Player {current_player} wins! Congratulations!")
        break
    elif is_board_full():
        display_board()
        print("It's a draw! You both are masters of Tic-Tac-Toe!")
        break

    current_player = "O" if current_player == "X" else "X"
